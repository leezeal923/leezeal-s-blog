import { Container } from '~/components/ui/Container'

export default function AboutPage() {
  return (
    <Container>
      <h1 className="mt-10">给我点时间开发一下...</h1>
    </Container>
  )
}
