export const navigationItems = [
  { href: '/', text: '首页' },
  { href: '/blog', text: '博客' },
  { href: '/projects', text: '项目' },
  { href: '/guestbook', text: '留言墙' },
  // { href: '/about', text: '关于' },
]
